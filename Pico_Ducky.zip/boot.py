import storage
storage.enable_usb_drive()